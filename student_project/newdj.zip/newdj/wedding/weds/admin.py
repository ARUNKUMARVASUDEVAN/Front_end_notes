from django.contrib import admin
from .models import catering,underwater,venue,contactus,makeup

# Register your models here.
admin.site.register(catering)
admin.site.register(underwater)
admin.site.register(venue)
admin.site.register(makeup)
admin.site.register(contactus)
